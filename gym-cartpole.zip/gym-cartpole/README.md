This environment is a cartpole.
Established by Keqin Wang (keqinw@andrew.cmu.edu)
Whole procedure follows the website: https://medium.com/@apoddar573/making-your-own-custom-environment-in-gym-c3b65ff8cdaa
Just for practice.